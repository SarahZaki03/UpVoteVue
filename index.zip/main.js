const submissionComponent = {
	template: `<div style="display: flex; width: 100%;">
	<figure class="media-left">
          <img class="image is-64x64"
            v-bind:src="datas.submissionImage">
        </figure>
        <div class="media-content">
          <div class="content">
            <p>
              <strong>
                <a href="#" class="has-text-info">{{ datas.title }}</a>
                <span class="tag is-small">{{ datas.id }}</span>
              </strong>
              <br>
                {{ datas.description }}
              <br>
              <small class="is-size-7">
                Submitted by:
                <img class="image is-24x24"
                  v-bind:src="datas.avatar">
              </small>
            </p>
          </div>
        </div>
        <div class="media-right">
          <span class="icon is-small" v-on:click="upvote(datas.id)">
            <i class="fa fa-chevron-up"></i>
            <strong class="has-text-info">{{ datas.votes }}</strong>
          </span>
        </div>
	</div>`,
	props: ['SendData','datas'],
	methods: {
		upvote(subid){
			const submission = this.SendData.find(
			submission => submission.id === subid
			  );
			  submission.votes++;
		}
	}
};
new Vue({
	el: '#app',
	data: {
		SendData: Seed.submissions
	},
	computed:{
		sortedSubmissions(){
			return this.SendData.sort((a,b) =>{
				return b.votes - a.votes
			});
		} 
	},
	components:{
		'submission-component': submissionComponent
	}
});